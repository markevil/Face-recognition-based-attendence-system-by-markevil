# face-recognition-based-attendance-system  





Face Recognition Based Attendance System

This project is a face recognition-based attendance system that uses Python and HTML programming languages. The system uses computer vision techniques to recognize faces in real-time and mark attendance based on the detected face.
Requirements

To run this project, you need to have the following software installed on your computer:

    Python 3.5 or higher
    OpenCV
    NumPy
    Pandas
    Flask

Installation

    Clone the repository or download the zip file.
    Install all the required libraries.
    Run the command python app.py to start the Flask server.
    Open the web browser and go to http://localhost:5000/ to access the attendance system.

Usage
    first login to the admin page.
    then add new user with "user name" and "user id". user id should be 10 digits only.
    then it will take 10 picture of the user and will store the photos in local storage.
    then click on "take attendance". it will open the camera and will mark your attendence and will save the data in local storage.
   

you can get this project on my github page ("https://github.com/markevil/Face-recognition-based-attendence-system-by-markevil")

